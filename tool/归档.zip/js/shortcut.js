//id,iconName,iconUrl,url,width,height
var shortcut = [
[0,"我的电脑","images/icons/icon_32_computer.png","tool/uid",700,500],
[1,"我的文档","images/icons/archive8.png","https://docs.qq.com/desktop/",1000,500],
[2,"华尔街快讯","images/icons/icon_32_network.png","https://wallstreetcn.com/live/global",770,500],
[3,"tools","images/icons/icon_16_system.png","tool/uid",730,500],
[4,"日历","images/icons/date.png","http://i.baidu.com/my/cal#monthView",1000,800],
[5,"腾讯课堂","images/icos/20.png","http://",1024,500],
[6,"百度随心听","images/icons/icon_22_disc.png","http://fm.baidu.com/",850,600],
[7,"优酷","images/icos/youku.png","http://www.youku.com/",1000,500],
];