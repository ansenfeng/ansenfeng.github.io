//
// Kick things off.
//
/* ´úÂëÕûÀí£ºÀÁÈËÖ®¼Ò lanrenzhijia.com */
jQuery(document).ready(function() {
	JQD.go();
});

//
// Namespace - Module Pattern.
//
var JQD = (function($, window, undefined) {
	// Expose innards of JQD.
	return {
		go: function() {
			for (var i in JQD.init) {
				JQD.init[i]();
			}
		},
		init: {

			clock: function() {
				if (!$('#clock').length) {
					return;
				}

				// Date variables.
				var date_obj = new Date();
				var hour = date_obj.getHours();
				var minute = date_obj.getMinutes();
				var day = date_obj.getDate();
				var year = date_obj.getFullYear();
				var suffix = '上午';

				// Array for weekday.
				var weekday = [
					'星期日',
					'星期一',
					'星期二',
					'星期三',
					'星期四',
					'星期五',
					'星期六'
				];

				// Array for month.
				var month = [
					'一月',
					'二月',
					'三月',
					'四月',
					'五月',
					'六月',
					'七月',
					'八月',
					'九月',
					'十月',
					'十一月',
					'十二月'
				];

				// Assign weekday, month, date, year.
				weekday = weekday[date_obj.getDay()];
				month = month[date_obj.getMonth()];

				// AM or PM?
				if (hour >= 12) {
					suffix = '下午';
				}


				// Leading zero, if needed.
				if (minute < 10) {
					minute = '0' + minute;
				}

				// Build two HTML strings.
				var clock_time = '登陆时间'+  ':' +weekday + ' ' + hour + ':' + minute + ' ' ;
				var clock_date = month + ' ' + day + ', ' + year;

				// Shove in the HTML.
				$('#clock').html(clock_time).attr('title', "这里显示首次登陆时间");
				$('#clock1').html(clock_date);

				// Update every 60 seconds.
				return false;
			},
			//
			// Initialize the desktop.
			//
			desktop: function() {

				$(document).mousedown(function(ev) {
					if (!$(ev.target).closest('a').length) {
						JQD.util.clear_active();
						ev.preventDefault();
						ev.stopPropagation();
					}
				}).bind('contextmenu', function() {
					return false;
				});


				$('a.menu_trigger').live('mousedown', function() {
					if ($(this).next('ul.menu').is(':hidden')) {
						JQD.util.clear_active();
						$(this).addClass('active').next('ul.menu').show();
					}
					else {
						JQD.util.clear_active();
					}
				}).live('mouseenter', function() {
					// Transfer focus, if already open.
					if ($('ul.menu').is(':visible')) {
						JQD.util.clear_active();
						$(this).addClass('active').next('ul.menu').show();
					}
				});

				$('a.menu_trigger1').live('mousedown', function() {
					if ($(this).next('ul.menu1').is(':hidden')) {
						JQD.util.clear_active();
						$(this).addClass('active').next('ul.menu1').show();
					}
					else {
						JQD.util.clear_active();
					}
				}).live('mouseenter', function() {
					// Transfer focus, if already open.
					if ($('ul.menu1').is(':visible')) {
						JQD.util.clear_active();
						$(this).addClass('active').next('ul.menu1').show();
					}
				});

				}

		},
		util: {
			//
			// Clear active states, hide menus.
			//
			clear_active: function() {
				$('a.active, tr.active').removeClass('active');
				$('ul.menu').hide();
				$('ul.menu1').hide();
			},


		}
	};
// Pass in jQuery.
})(jQuery, this);


function myFunction(){
 ZENG.msgbox.show("桃花坞里桃花庵，桃花庵里桃花仙，桃花仙人种桃树，又摘桃花换酒钱。", 5, 20000);
 $('ul.menu').hide();
 $('a.active, tr.active').removeClass('active');
};



